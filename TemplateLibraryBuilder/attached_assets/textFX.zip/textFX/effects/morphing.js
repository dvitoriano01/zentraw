console.log("Morphing effect loaded.");
// Simples animação SVG stroke dashoffset no texto
