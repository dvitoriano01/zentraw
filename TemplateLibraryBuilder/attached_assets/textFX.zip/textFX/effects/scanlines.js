console.log("VHS Scanlines effect loaded.");
// Efeito de scanlines feito em CSS.
