console.log("Stretch + Bounce effect loaded.");
// Efeito ativado por CSS na classe .stretch-text
